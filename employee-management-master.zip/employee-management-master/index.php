
<?php
session_start();
include_once "config/constants.php";
include_once LIBS . "app.php";
require_once LIBS . "sessionHelper.php";

$app = new App();

?>