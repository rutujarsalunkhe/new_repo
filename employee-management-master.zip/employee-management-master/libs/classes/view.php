
<?php

class View{

    function __construct(){
    }
}

?>