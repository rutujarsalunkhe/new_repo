<?php

// Host

define("HOST", "localhost");

//Port
define("PORT", "3306");

// Database

define("DATABASE", "employeesv3");

// User

define("USER", "root");

// Password

define("PASSWORD", "");